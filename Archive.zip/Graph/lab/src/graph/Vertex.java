package graph;

import java.util.ArrayList;

public class Vertex {

	public Vertex() {
		// TODO Auto-generated constructor stub
	}

	public void addVertex(Vertex v) {
		// TODO Auto-generated method stub
		
	}

	public Vertex removeVertex(Vertex v, ArrayList<Edge> e) {
		// TODO Auto-generated method stub
		return null;
	}

}

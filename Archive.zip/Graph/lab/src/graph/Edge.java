package graph;

public abstract class Edge implements Graph{
	Vertex vertices[];
}

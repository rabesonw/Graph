package graph;

import java.util.ArrayList;

public class DirectedEdge extends Edge{
	
	public DirectedEdge() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void addVertex(Vertex v) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Vertex removeVertex(Vertex v, ArrayList<Edge> e) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addEdge(Edge e, Vertex v1, Vertex v2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Edge removeEdge(Edge e) {
		// TODO Auto-generated method stub
		return null;
	}

}

package maze;

import java.io.*;

import implementation.*;

public class Maze extends MyGraph implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	int height;
	int width;
	Cell cells[][];
	
	/**
	 * creates a maze of width width and height height
	 * with cells of empty type
	 * 
	 * @param int width, int height
	 * */
	public Maze(int width, int height) {
		this.height = height;
		this.width = width;
		this.cells = new Cell[width][height];
		for(int i = 0; i<this.width; i++) {
			for(int j = 0; j<this.height; j++) {
				this.cells[i][j] = new Cell(i, j, CellEnum.EMPTY);
			}
		}
	}
	
	public void setStart(int x, int y) {
		this.cells[x][y].setType(CellEnum.START);
	}
	
	public void setExit(int x, int y) {
		this.cells[x][y].setType(CellEnum.END);
	}
	
	public void setWall(int x, int y) {
		this.cells[x][y].setType(CellEnum.WALL);
	}
	
	public void setEmpty(int x, int y) {
		this.cells[x][y].setType(CellEnum.EMPTY);
	}
	
	public String toString() {
		String s = new String();
		for(int i = 0; i<this.width; i++) {
			for(int j = 0; j<this.height; j++) {
				if (this.cells[i][j].getType() == CellEnum.WALL) {
					s+="W";
				} else if(this.cells[i][j].getType() == CellEnum.START) {
					s+="D";
				} else if(this.cells[i][j].getType() == CellEnum.END) {
					s+="A";
				} else {
					s+=".";
				}
			}
			s+="\n";
		}
		return s;
	}
}

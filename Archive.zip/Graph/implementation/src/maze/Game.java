package maze;

import java.io.*;
import java.util.*;

public class Game {
	
	public static void saveMaze(Maze maze, String filename) {
		try {
			FileOutputStream file = new FileOutputStream(filename);
			ObjectOutputStream out = new ObjectOutputStream(file);
			
			out.writeObject(maze);
			
			out.close();
			file.close();
			
		} catch (IOException e) {
			System.out.println("Failed");
		} 
	}
	
	public static Maze loadMaze(String filename) {
		Maze m = null;
		try {
			FileInputStream file = new FileInputStream(filename);
			ObjectInputStream in = new ObjectInputStream(file);
			
			m = (Maze) in.readObject();
			
			in.close();
			file.close();
			
		} catch (IOException e) {
			System.out.println("Failed");
		} catch (ClassNotFoundException ec) {
			System.out.println("Failed");
		}
		return m;
	}
	
	public static Maze buildMaze(int x, int y) {
		Maze built = new Maze(x, y);
		
		return built;
	}
	
	public static void main(String[] args) {
		String filename = "YourMaze";
		System.out.println("Welcome to the Maze");
		System.out.println("Would you like to build [1], play [2] or load [3] a Maze ?");
		Scanner sc = new Scanner(System.in);
		int i = sc.nextInt();
		
		boolean command = true;
		
		while (command) {
			if (i == 1) {
				System.out.println("Please give a width for the Maze");
				int x = sc.nextInt();
				System.out.println("Please give a height for the Maze");
				int y = sc.nextInt();
				Maze built = buildMaze(x, y);
				saveMaze(built, filename);
				command = false;
			} else if (i == 2) {
				Maze m = new Maze(3, 3);
				m.setStart(0, 0);
				m.setExit(2, 2);
				m.setWall(1, 1);
				
				System.out.println(m.toString());
				/* prints out :
				 * D..
				 * .W.
				 * ..A 
				 */
				command = false;
			} else if (i == 3) {
				Maze newMaze = loadMaze(filename);
				System.out.println(newMaze.toString());
				command = false;
			} else {
				System.out.println("Wrong number, 1, 2 or 3 please");
				i = sc.nextInt();
			}
		}
		
		sc.close();
		
	}
}

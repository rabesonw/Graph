package maze;

public enum CellEnum {
	START, 
	END, 
	WALL, 
	EMPTY;
}

package maze;

import graph.*;

public class Cell extends Vertex {
	int x;
	int y;
	
	public Cell(int x, int y, CellEnum type) {
		super(type);
		this.x = x;
		this.y = y;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public CellEnum getType() {
		return (CellEnum) super.getContent();
	}

	public void setType(CellEnum type) {
		super.setContent(type);
	}
	
	
}
